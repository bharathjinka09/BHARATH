import os

retval =  os.system("lss")
print "retval :", hex(retval)
