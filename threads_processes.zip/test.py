import os
import sys

print ("Mypid :", os.getpid())

sys.exit(-1)
''' 
if (open == 0)
	sys.exit(0)
else
	sys.exit(-1)
''' 
