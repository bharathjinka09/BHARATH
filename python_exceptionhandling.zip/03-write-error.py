#!/usr/bin/python
def sample1():
	try:
		fd = open("users.csv", "r")
		fd.write("Writing to file")
		fd.close()
		print("I am in try block")

	except IOError as err:
		print ("File write failed")
	else:
		print("Success in opeing file")

	finally:
		print("I am in finally block")

def sample2():
	try:
		fd = open("users.csv", "r")
		fd.write("Writing to file")
		fd.close()
		print("I am in try block")

	except IOError as err:
		print ("File write failed :%s" % (err.strerror))
		print ("Error arguments :%s" % (err.args))
		print ("My message : File write failed")
	else:
		print("Success in opeing file")

	finally:
		print("I am in finally block")

def sample3():
	try:
		fd = open("user.csv", "r")
		fd.close()
		print("I am in try block")

	except IOError as err:
		print ("File Open failed errno :%d, message :%s" % (err.errno, err.strerror))
		print(err.args)
	else:
		print("Success in opeing file")

	finally:
		print("I am in finally block")

def main():
	#sample1()
	#sample2()
	sample3()


if (__name__ == "__main__"):
	main()
