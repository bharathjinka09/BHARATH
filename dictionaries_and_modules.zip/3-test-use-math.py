#import amath
from amath import is_prime
#import fact
#from fact import factorial



n = 17
#if (amath.is_prime(n)):
if (is_prime(n)):
    print n, "Prime"
else:
    print n, "NOT Prime"

