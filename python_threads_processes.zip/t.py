import time

while(1):
    print("Hello")
    time.sleep(1)
