import sys

n = 5

n = int(sys.argv[1])

for i in range (1, n+1):
	print i, 

print sys.argv
print sys.argv[0]
print len(sys.argv)

for args in sys.argv:
    print args


fd = open(sys.argv[2], "r")

list_of_servers = fd.readlines()

print list_of_servers 

for server in list_of_servers:
    print server

