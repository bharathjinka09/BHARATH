a = 2
print(('id(2) =', id(2)))
print(('id(a) =', id(a)))

a = a + 1
print(('id(2) =', id(2)))
print(('id(a) =', id(a)))
print(('id(3) =', id(3)))


b = 2
print(('id(2) =', id(2)))
print(('id(b) =', id(b)))

b = b + 1
print(('id(3) =', id(3)))
print(('id(b) =', id(b)))
exit(1)

